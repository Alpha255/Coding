//
// Visual Assist X helpers
//
// These definitions take precedence over the ones in the solution
// effectively causing VA to ignore those in the solution.
//


//
// namespace macros
//
#define popBEGIN_NAMESPACE                              namespace scimitar {
#define popEND_NAMESPACE                                }


//
// C++ class definition macros that hose VA.
//
#define POP_ENGINE_DLL
#define POP_SYSTEM_DLL
#define POP_ASSASSIN2_DLL
#define POP_ASSASSIN2INTERFACE_DLL
#define POP_UNITTEST_DLL

//
// Additional macros that will screw up VA when placed before the popBEGIN_NAMESPACE
//
#define popDeclareSpuProfile(x)                            { }


//
// zen parsing help
// zen files are similar to c++, but not close enough that VA doesn't need help
//

// treat "extends" as ": public" class inheritance
#define extends : public

// ignore "import" keyword
#define import
